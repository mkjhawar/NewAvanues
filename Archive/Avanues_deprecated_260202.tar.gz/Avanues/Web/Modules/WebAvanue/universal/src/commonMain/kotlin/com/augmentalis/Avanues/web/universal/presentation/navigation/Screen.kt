package com.augmentalis.Avanues.web.universal.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.augmentalis.webavanue.domain.repository.BrowserRepository
import com.augmentalis.Avanues.web.universal.presentation.ui.bookmark.BookmarkListScreen
import com.augmentalis.Avanues.web.universal.presentation.ui.browser.BrowserScreen
import com.augmentalis.Avanues.web.universal.presentation.ui.download.DownloadListScreen
import com.augmentalis.Avanues.web.universal.presentation.ui.history.HistoryScreen
import com.augmentalis.Avanues.web.universal.presentation.ui.settings.SettingsScreen
import com.augmentalis.Avanues.web.universal.presentation.viewmodel.*

/**
 * ViewModelHolder - Holds all ViewModels for the browser app
 * Used to pass ViewModels through Voyager navigation
 */
data class ViewModelHolder(
    val repository: BrowserRepository,
    val tabViewModel: TabViewModel,
    val favoriteViewModel: FavoriteViewModel,
    val downloadViewModel: DownloadViewModel,
    val historyViewModel: HistoryViewModel,
    val settingsViewModel: SettingsViewModel
) {
    companion object {
        fun create(repository: BrowserRepository): ViewModelHolder {
            return ViewModelHolder(
                repository = repository,
                tabViewModel = TabViewModel(repository),
                favoriteViewModel = FavoriteViewModel(repository),
                downloadViewModel = DownloadViewModel(repository),
                historyViewModel = HistoryViewModel(repository),
                settingsViewModel = SettingsViewModel(repository)
            )
        }
    }
}

/**
 * BrowserScreenNav - Main browser screen with tab bar and WebView
 */
data class BrowserScreenNav(
    val viewModels: ViewModelHolder,
    val xrManager: Any? = null,  // XRManager on Android, null on other platforms
    val xrState: Any? = null     // XRManager.XRState on Android, null on other platforms
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        BrowserScreen(
            tabViewModel = viewModels.tabViewModel,
            settingsViewModel = viewModels.settingsViewModel,
            historyViewModel = viewModels.historyViewModel,
            favoriteViewModel = viewModels.favoriteViewModel,
            downloadViewModel = viewModels.downloadViewModel,  // FIX: Pass downloadViewModel for tracking
            xrManager = xrManager,
            xrState = xrState,
            onNavigateToBookmarks = {
                navigator.push(BookmarksScreenNav(viewModels))
            },
            onNavigateToDownloads = {
                navigator.push(DownloadsScreenNav(viewModels))
            },
            onNavigateToHistory = {
                navigator.push(HistoryScreenNav(viewModels))
            },
            onNavigateToSettings = {
                navigator.push(SettingsScreenNav(viewModels))
            },
            onNavigateToXRSettings = {
                navigator.push(XRSettingsScreenNav(viewModels))
            }
        )
    }
}

/**
 * BookmarksScreenNav - Bookmark/Favorite management screen
 */
data class BookmarksScreenNav(
    val viewModels: ViewModelHolder,
    val folderId: String? = null
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        // Filter by folder if specified
        if (folderId != null) {
            viewModels.favoriteViewModel.filterByFolder(folderId)
        }

        BookmarkListScreen(
            viewModel = viewModels.favoriteViewModel,
            onNavigateBack = {
                if (folderId != null) {
                    viewModels.favoriteViewModel.filterByFolder(null)
                }
                navigator.pop()
            },
            onBookmarkClick = { url ->
                viewModels.tabViewModel.navigateToUrl(url)
                navigator.popUntilRoot()
            }
        )
    }
}

/**
 * DownloadsScreenNav - Download management screen
 */
data class DownloadsScreenNav(
    val viewModels: ViewModelHolder
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        DownloadListScreen(
            viewModel = viewModels.downloadViewModel,
            onNavigateBack = {
                navigator.pop()
            },
            onDownloadClick = { download ->
                // TODO: Open downloaded file
            }
        )
    }
}

/**
 * HistoryScreenNav - Browsing history screen
 */
data class HistoryScreenNav(
    val viewModels: ViewModelHolder
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        HistoryScreen(
            viewModel = viewModels.historyViewModel,
            onNavigateBack = {
                navigator.pop()
            },
            onHistoryClick = { url ->
                viewModels.tabViewModel.navigateToUrl(url)
                navigator.popUntilRoot()
            }
        )
    }
}

/**
 * SettingsScreenNav - Browser settings screen
 */
data class SettingsScreenNav(
    val viewModels: ViewModelHolder
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        SettingsScreen(
            viewModel = viewModels.settingsViewModel,
            onNavigateBack = {
                navigator.pop()
            },
            onNavigateToXRSettings = {
                navigator.push(XRSettingsScreenNav(viewModels))
            }
        )
    }
}

/**
 * XRSettingsScreenNav - WebXR settings screen
 * Note: XR features only work on Android, but UI is cross-platform
 */
data class XRSettingsScreenNav(
    val viewModels: ViewModelHolder
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        val settings by viewModels.settingsViewModel.settings.collectAsState()

        // Only show XR settings if settings are loaded
        settings?.let { currentSettings ->
            com.augmentalis.Avanues.web.universal.presentation.ui.xr.XRSettingsScreen(
                settings = currentSettings,
                onSettingsChange = { newSettings ->
                    viewModels.settingsViewModel.updateSettings(newSettings)
                },
                onNavigateBack = {
                    navigator.pop()
                }
            )
        }
    }
}

/**
 * AboutScreenNav - About screen (app info, version, licenses)
 */
data class AboutScreenNav(
    val viewModels: ViewModelHolder
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow

        // TODO: Create AboutScreen composable
        // For now, just pop back
        navigator.pop()
    }
}
